export class Diagnostico {

  public paciente: string;
  public doctor: string;
  public fecha: string;
  public sintoma: string;
  public diagnostico: string;
  public id: number;


	constructor()
	{
    this.paciente="";
		this.id=0;
	}

}
