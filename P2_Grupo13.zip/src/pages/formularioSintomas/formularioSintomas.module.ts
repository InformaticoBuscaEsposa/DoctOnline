import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FormularioSintomasPage } from './formularioSintomas';

@NgModule({
  declarations: [
    FormularioSintomasPage,
  ],
  imports: [
    IonicPageModule.forChild(FormularioSintomasPage),
  ],
})
export class FormularioSintomasPageModule {}
