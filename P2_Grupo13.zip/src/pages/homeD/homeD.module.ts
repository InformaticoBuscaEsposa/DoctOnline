import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HomeDPage } from './homeD';

@NgModule({
  declarations: [
    HomeDPage,
  ],
  imports: [
    IonicPageModule.forChild(HomeDPage),
  ],
})
export class HomeDPageModule {}
